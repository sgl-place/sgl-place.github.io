********************************
***   Advance Map Ver 1.20   ***
********************************

Dieses Programm ist f�r das editieren von Maps, Gehdaten und Blockdaten.
Sp�ter sollten auch noch Events, Kollisionsdaten und Wildepokemon- Daten editierbar sein.
Es l�uft mit Pokemon Ruby und Sappiere, Japanisch und Englisch.

********************************
***        Map finden        ***
********************************
Es ist wichtig, das die Breite und die H�he der Map stimmt,
es ist n�mlich so, das es den Offset gerade am Ende der Map brauch.
Also es nimmt die Position wo das komische Zeug anf�ngt (Rechnet es aus).
Ihr k�nnt auch den Begin des komischen Zeugs nehmen und diesen Offset Manuel in die inis
eintragen, zu beachten ist aber das dies zur Map dar�ber geh�rt.

!!!Wichtig!!!
-------------
Wen ihr die Offsets Manuel eintr�gt, m�sst Ihr die von Sapp Englisch nehmen.


********************************
***     Inhalt der inis      ***
********************************
AdvanceMap.ini:
--------------- 
Hier steht der Name des Roms und einige Eigenschaften z.B.:
Die Verschiebung:
Da steht das Resultat der Rechnung:
TilesetHeader(von POKEMON SAPPAXPE[Englisch]) - TilesetHeader (von entsprechendem Rom)
Oder auch der Unterschied einer Map von sapp eng und der gleichen Map des entsprechenden Roms.


Main.ini
--------
Hier sind die Ordner mit den entsprechenden Maps aufgelistet.
Es k�nnen beliebig Viele neue Ordner erstelt werden.
Der Aufbau sieht so aus:
[Towns]
1=Town
2=Town2
3=Town3
...

[Routen]
1=Route
...


Maps.ini
--------
Hier sind die Maps aufgelistet, es erscheinen nur die,
welche in der liste der Ordner vorkommen.
[Town]
Offset=$287904
Name=Town1

[Route]
Offset=$29C8F4
Name=Route101

In der Mapliste werden diese zwei eintr�ge so erscheinen:
Towns
  -Town1 (Town)
  -...
Routen
  Route101 (Route)

In der klammer(Eintragsname in[]) kann auch die nummer dieser Map im Header stehen!

Tilesets.ini
------------
Jedes "Tilesets" bestehen aus 2 Teilen, sie m�ssen beim Bild vom VisualBoyAdvance in der Mitte halbiert werden.
Die Bilder m�ssen in der umgeformten Breit von 16 Tiles vorhanden sein.
Hier ist es so das die Tilesets nach der Reihenfolge im Rom sortiert sind, hier wird der TilesetHeader- Wert verwendet.
Es muss immer zuerst die [Nummer] stehen(erstes ist das Nullte).
Danach "Tiles=" und der Name der ".dib"- Datei ("dib" ist das gleiche wie "bmp� nur mit einer anderen Endung).
Optional kann auch noch stehen wie viele Blocks es hat "Blocks=$90".
Das wichtigste ist das alle Bilder in einer Pallete gespeichert sind, welche 16 verschiedene Farben hat.
Ich habe Standardm�ssig die Pallete 3 genommen. 
Ist jedoch eine andere notwendig, muss dies festgehalten werden "Start Pal=" und die Nummer.
Ich habe die Bezeichnung "Haupt" genommen wen sich das Tileset Standardm�ssig im oberen Teil befindet.
Wenn sich ein Tileset im oberen Teil befindet, hat sie automatisch 200 Bl�cke.

[0]
Tiles=Haupt.dib

[1]
Tiles=Tileset1.dib
Blocks=$90

...

[14]
Tiles=Haupt2.dib
Start Pal=1



********************************
***          Greats          ***
********************************
Der gr�sste Gruss geht an:
Jigglypuff f�r den Source von Goldmap2 Beta.

Weitere gr�sse gehen an:
F-Zero und Tauwasser f�r Ihr grosses Tut.
Bim f�r seine Dienste.
Und nat�rlich Filb f�r sein Board.
