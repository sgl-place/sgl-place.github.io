********************************
***   Advance Map Ver 1.30   ***
********************************

Dieses Programm ist f�r das editieren von Maps, Gehdaten und Blockdaten.
Sp�ter sollten auch noch Events, Kollisionsdaten und Wildepokemon- Daten editierbar sein.
Es l�uft mit Pokemon Ruby und Sappiere, Japanisch und Englisch.

********************************
***        Map finden        ***
********************************
Es ist wichtig, das die Breite und die H�he der Map stimmt,
es ist n�mlich so, das es den Offset gerade am Ende der Map brauch.
Also es nimmt die Position wo das komische Zeug anf�ngt (Rechnet es aus).
Ihr k�nnt auch den Begin des komischen Zeugs nehmen und diesen Offset Manuel in die inis
eintragen, zu beachten ist aber das dies zur Map dar�ber geh�rt.
(Es sind schon alle maps Vorhanden^^)

!!!Wichtig!!!
-------------
Wen ihr die Offsets Manuel eintr�gt, m�sst Ihr die von Sapp Englisch nehmen.


********************************
***     Inhalt der inis      ***
********************************
AdvanceMap.ini:
--------------- 
Hier steht der Name des Roms und einige Eigenschaften z.B.:
Die Verschiebung:
Da steht das Resultat der Rechnung:
TilesetHeader(von POKEMON SAPPAXPE[Englisch]) - TilesetHeader (von entsprechendem Rom)
Oder auch der Unterschied einer Map von sapp eng und der gleichen Map des entsprechenden Roms.


Main.ini
--------
Hier sind die Ordner mit den entsprechenden Maps aufgelistet.
Es k�nnen beliebig Viele neue Ordner erstelt werden.
Der Aufbau sieht so aus:
[0]
1=0.0
2=0.1
3=0.2
...

[1]
1=1.0
...

Die Ordnernamen d�rfen frei ge�ndert werden, auch die Eintr�ge;

Maps.ini
--------
Hier sind die Maps aufgelistet, es erscheinen nur die,
welche in der liste der Ordner vorkommen.
[0.0]
Name=PETALBURG CITY
Offset=$287904

[1.0]
Name=Route 101
Offset=$29C8F4

Wichtig:
Hier sollte man nur die 'Name'- Eigenschaft �ndern, und die 1.0 oder so lassen.
Diese zahlen werden in der sp�teren Versionen gebraucht, sie geben n�mlich die Position im Header an!


Tilesets.ini
------------
Diese Datei muss existieren, sie kann aber lehr sein!
Die Tileset-Bilder werden ab der ver 1.30 aus dem spiel geladen.
Optional kann hier zu jedem Tileset(bei 0 beginend) stehen wie viele Blocks es hat "Blocks=$90".
Wenn sich ein Tileset im oberen Teil befindet, hat es automatisch 200 Bl�cke.

[1]
Blocks=$90

...

[24]
Blocks=$87



********************************
***          Greats          ***
********************************
Der gr�sste Gruss geht an:
Jigglypuff f�r den Source von Goldmap2 Beta.

Weitere gr�sse gehen an:
Tauwasser und F-Zero f�r Ihre Tuts.
Bim f�r seine Dienste.
Serwe der mich auf ein paar Ideen gebracht hat.
Und nat�rlich Filb f�r sein Board.
