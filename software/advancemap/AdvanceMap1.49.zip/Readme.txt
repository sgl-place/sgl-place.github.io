********************************
***   Advance Map Ver 1.49   ***
********************************

Dieses Programm ist f�r das editieren von Maps, Gehdaten, Blockdaten, Events und Wildepokemondaten.
Sp�ter sollte auch noch Kollisionsdaten editierbar sein.
Es l�uft mit Pokemon Ruby und Sappiere, Japanisch,Englisch und Deutsch(Sapp).

!!!Achtung!!!
-------------
Bei dieser Version werden alle enderungen direkt ins Rom gespeichert!
Durch Speichern unter kann man die aktuelle Map in eine andere Datei speichern.
Die Datei wird zuerst erstellt, indem die aktuelle Datei kopiert wird.
Alle weiteren enderungen werden dan in die neue datei gespeichert.


.:|WICHTIG|:.
-^-^-^-^-^-^-
Dieses Programm wurde von LU-HO Pok� programmiert und ist somit Copyright by LU-HO Pok�!
Wenn ihr es von einem anderen Ort als vom FWB(Filb's World Board[ http://www.filbboard.de ]) runtergeladen habt,
sagt mir doch Bitte bescheid! Meine mail ist: lu.ho@tiscali.ch


********************************
***     Inhalt der inis      ***
********************************
AdvanceMap.ini:
--------------- 
Hier steht der Name des Roms und einige Eigenschaften z.B.:
MapBankHeader: Offset des MapBank Headers
NamenHeader= Offset des NamenHeaders(Maps)
WildePokemon= Offset des Wilden Pokemon Headers
TilesetHeader= Offset des Tileset Headers

Bei Hex Werten muss ein "$" davor!


Main.ini
--------
Hier sind die Ordner mit den entsprechenden Maps aufgelistet.
Es k�nnen beliebig Viele neue Ordner erstelt werden.
Der Aufbau sieht so aus:
[0]
1=0.0
2=0.1
3=0.2
...

[1]
1=1.0
...

Die Ordnernamen d�rfen frei ge�ndert werden;


Maps.ini
--------
Hier sind die Maps aufgelistet, es erscheinen nur die,
welche in der liste der Ordner vorkommen.
[0.0]
Name=PETALBURG CITY
Offset=$287904

[1.0]
Name=Route 101
Offset=$29C8F4

Wichtig:
Hier sollte man nur die 'Name'- Eigenschaft �ndern.
Die Namensgebung des Eintrages "[0.0]" bezieht sich auf die Position im Mapheader,
wird dies ge�ndert, funktionieren diese Maps nicht mehr!
Die offsets werden nicht mehr gebarauch, d�rfen aber trozdem drin bleiben.


Tilesets.ini
------------
Die Tileset-Bilder werden ab der ver 1.30 aus dem spiel geladen.
Optional kann hier zu jedem Tileset(erstes Tileset ist 0) stehen wie viele Blocks es hat "Blocks=$90".
Wenn sich ein Tileset im oberen Teil befindet, hat es automatisch 200 Bl�cke.

[1]
Blocks=$90

...

[24]
Blocks=$87


Pokemon.ini
-----------
Da sind die Namen f�r die Pokemon aufgelistet:
[Pokemon]
0=Bitte w�hlen     // das muss hier sein, sonst werden eventuel die Daten Falsch angezeigt.
1=Bisasam
2=Bisaknosp
3=Bisaflor
... 


Sprachen.ini
------------
Da sind die Daten f�r die verschiedenen Sprachen auf gelistet.
Es k�nnen beliebig viele andere Sprachen hinzugef�gt werden, beachten sie aber den "EndNutzer Vertrag".
Die Sprache ist unter "Einstellungen"->"Sprache" ausw�hlbar.


GehDaten.ini
------------
Hier stehen die bedeutungen der GehDaten. Sie sind auch in verschiedenen Sprachen vorhanden.
Achtung:Die Eintr�ge ([Deutsch]/[English]/...) m�ssen die gleichen namen haben wie bei der "Sprachen.ini"!
Die werte m�ssen mit 2 stellingen Hexzahlen angegeben werden:
[Deutsch]
00=Durchl�ssigkeit immer
...
0C=Mit allen Dingen Begehbar
...



********************************
***          Greats          ***
********************************
Der gr�sste Gruss geht an:
Jigglypuff f�r den Source von Goldmap2 Beta
und Jay, der ihn �bermittelt hat.

Weitere gr�sse gehen an:
Tauwasser und F-Zero f�r Ihre Tuts.
Mikaron f�r seine Dienste.
Serwe der mich auf ein paar Ideen gebracht hat.
Mulle die mich auf einen Feher hinwies.
darkmaster01, Chiklit und Mikaron f�r die �bersetzungen.
Und nat�rlich Filb f�r sein Board.
