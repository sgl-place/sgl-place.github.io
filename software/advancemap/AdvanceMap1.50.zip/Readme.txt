********************************
***   Advance Map Ver 1.50   ***
********************************

Dieses Programm ist f�r das editieren von Maps, Gehdaten, Aufgabendaten, Blockdaten, Events und Wildepokemondaten.
Es l�uft mit Pokemon Ruby und Sappiere in den Sprachen: Japanisch, Englisch, Deutsch, Fraz�sisch, Italienisch und Spanisch.

!!!Achtung!!!
-------------
Es werden alle enderungen direkt ins Rom gespeichert!
Durch Speichern unter kann man die aktuelle Map in eine andere Datei speichern.
Die Datei wird zuerst erstellt, indem die aktuelle Datei kopiert wird.
Alle weiteren enderungen werden dann in die neue datei gespeichert.



.:|WICHTIG|:.
-^-^-^-^-^-^-
Dieses Programm wurde von LU-HO Pok� programmiert und ist somit Copyright by LU-HO Pok�!
Dies wurde von Jiggly (programmierer von Goldmap 2 Beta) Officiel best�tigt.
Wen ihr AM von wo anderst als vom FWB(Filb's World Board), von www.LU-HO.ch.vu oder von
www.romhackersworld.de.vu runtergeladen habt, richtet mir das Bitte per E-Mail aus!



****************************
***   Ganz Wichtig!!!!   ***
****************************
Ich habe mich mit Jiggly(programmierer von Goldmap 2 Beta) unterhalten, da ein paar Leute
immer noch darauf bestehen das ich den Source frei gebe.
Wir sind auf das Ergebnis gekommen, das Goldmap Copyright By Jiggly ist (ist ja klar) und
das Advance Map, also alle Versionen (alte, jetzige und zuk�nftige) Copyright By LU-HO sind!
Advance Map ist somit mein Produkt und ich besitze alle Recht daf�r!



********************************
***     Inhalt der inis      ***
********************************
AdvanceMap.ini:
--------------- 
Hier steht der Name des Roms und einige Eigenschaften z.B.:
MapBankHeader= Offset des MapBank Headers
NamenHeader= Offset des NamenHeaders(Maps)
WildePokemon= Offset des Wilden Pokemon Headers
TilesetHeader= Offset des Tileset Headers
PokemonNamen= Offset der Pokemonnamen
Namenl�nge= abstand der Pokemonnamen (wenn 11, dann wird es nicht ben�tigt!)
Table= Dateiname der verwendeten table

Bei Hex Werten muss ein "$" davor stehen!


Main.ini
--------
Hier sind die Ordner mit den entsprechenden Maps aufgelistet.
Es k�nnen beliebig Viele neue Ordner erstelt werden.
Der Aufbau sieht so aus:
[0]
1=0.0
2=0.1
3=0.2
...

[1]
1=1.0
...

Die Ordnernamen d�rfen frei ge�ndert werden;


Maps.ini
--------
Hier sind die Maps aufgelistet, es erscheinen nur die,
welche in der liste der Ordner vorkommen.
[0.0]
Name=PETALBURG CITY

[1.0]
Name=Route 101

Wichtig:
Hier sollte man nur die 'Name'- Eigenschaft �ndern.
Die Namensgebung des Eintrages "[0.0]" bezieht sich auf die Position im Mapheader,
wird dies ge�ndert, funktionieren diese Maps nicht mehr!
AUSSER:
Wenn man eine Offset eigenschaft hat, welche folgend aufgebaut sein muss:
Romname=Offset
z.B. : 
[Route1]
Name=Route 101
POKEMON SAPPAXPD=$29C8F4


Tilesets.ini
------------
Die Tileset-Bilder werden ab der ver 1.30 aus dem spiel geladen.
Optional kann hier zu jedem Tileset(erstes Tileset ist 0) stehen wie viele Blocks es hat "Blocks=$90".
Wenn sich ein Tileset im oberen Teil befindet, hat es automatisch 200 Bl�cke.

[1]
Blocks=$90

...

[24]
Blocks=$87


Sprachen.ini
------------
Da sind die Daten f�r die verschiedenen Sprachen auf gelistet.
Es k�nnen beliebig viele andere Sprachen hinzugef�gt werden, beachten sie aber den "EndNutzer Vertrag".
Die Sprache ist unter "Einstellungen"->"Sprache" ausw�hlbar.

Die Sprache, die hier zu oberst steht, wird als Standart Sprache genommen, sind keine Daten vorhanden,
wird die Standart Deutsche Beschriftung verwendet.


GehDaten.ini
------------
Hier stehen die bedeutungen der GehDaten. Sie sind auch in verschiedenen Sprachen vorhanden.
Achtung:Die Eintr�ge ([Deutsch]/[English]/...) m�ssen die gleichen namen haben wie bei der "Sprachen.ini"!
Die werte m�ssen mit 2 stellingen Hexzahlen angegeben werden:
[Deutsch]
00=Durchl�ssigkeit immer
...
0C=Mit allen Dingen Begehbar
...


AufgabenDaten.ini
-----------------
Hier stehen die informationen f�r die Aufgabendaten.
Beispiele:
[Aufgaben]
02=Animation von Gras(PKMN) 
03=Animation hoches Grass 
06=SandFussSpuren(mit Sandhaufen)

[Hintergrund]
10=Block wird von HIRO verdeckt
40=Wird zu Rand

Bei alle Daten die ausgelassen werden, wird im Programm einfach ihr HEX Wert eingetragen.


Table.Ini bzw.Table jap.ini
---------------------------
Das sind 2 fast ganz gew�ndliche Tablefiles. Sie werden ben�tigt um die Map- und Pokenamen aus dem Spiel zu lesen.

[Table]
00=" "
15=�
1B=�
A1=0
A2=1

Hier muss einfach beachtet werden, das zu begin "[Table]" steht.
Das Leerzeichen muss in anf�rungszeichen gesetzt werden, sonnst wird es nicht erkannt.



********************************
***          Greats          ***
********************************
Der gr�sste Gruss geht an:
Jigglypuff f�r den Source von Goldmap2 Beta
und Jay, der ihn �bermittelt hat.

Weitere gr�sse gehen an:
Tauwasser und F-Zero f�r Ihre Tuts.
Mikaron f�r seine Dienste.
Serwe der mich auf ein paar Ideen gebracht hat.
Mulle die mich auf einen Feher hinwies.
darkmaster01, Chiklit und Mikaron f�r die �bersetzungen.
Alle anderen die mir geholfen haben.
Und nat�rlich Filb f�r sein Board.