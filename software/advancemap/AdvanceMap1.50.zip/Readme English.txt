********************************************
*** Advance Map Ver 1.48 - English (Alt) ***
********************************************

This program is for the editing of Map, movement permissions, block data, events and wild pokemon data.
Later collision data should also be editable.
It runs with Pokemon Ruby and Sapphire, Japanese and English.

!!!Attention!!!
-------------
With this version all changes are saved directly into the rom!
Through "Save As" you can save the current map into another file.
Once loaded a copy of the current file is made.
All further changes are stored into the new file.



.:|IMPORTANT|:.
-^-^-^-^-^-^-
This program was programmed by LU-HO Pok� and is consequently copyrightED by LU-HO Pok�!
If you downloaded it from another place then from the FWB(Filb's World board [http://www.filbboard.de]),
please tell me right away! My mail is: lu.ho@tiscali.ch


********************************
***        Map Finding       ***
********************************
It is important that the width and height of the map fit so that it need the offset
to be exactly at the end of the map.
Therefore it takes the position where the funny stuff starts.
You can also take the offset of the begining of the funny stuff and put it in the inis,
however this belongs to the map above it.
(All of the maps already exist^^)

!!!Attention!!!
-------------
When you put the offset it you must put in the offset for the English version of Sapphire.


********************************
***     Contents of Inis     ***
********************************
AdvanceMap.ini:
--------------- 
Here is the name of the roms and a few properties ex.:
The Offset offset:
Thats where the result of this caculation is:
TilesetHeader(of POKEMON SAPPAXPE[English]) - TilesetHeader (of corrosponding Rom)
Or also you could put the difference in offsets between the sapphire map and the same map of the corresponding rom.
(Die Eigenschaft Verschiebung wird in dieser Version nicht mehr ben�tigt, da es die daten aus dem Header liest)


Main.ini
--------
Here the orders with the corresponding maps are listed.
Many new orders can be produced at will.
The format is as follows:
[0]
1=0.0
2=0.1
3=0.2
...

[1]
1=1.0
...

The names of the maps can also be edited;

Maps.ini
--------
Here the maps are listed, but only the ones that are listed in Main.ini
appear.
[0.0]
Name=PETALBURG CITY
Offset=$287904

[1.0]
Name=Route 101
Offset=$29C8F4

Important:
Here you should only alter the 'name' attribute.
The heading of the entry "[0.0]" refers to the position in the map header, if this is altered
then the maps will no longer work!
The offsets are no longer used in this version, however they can remain in there.


Tilesets.ini
------------
The tileset-builder is new from version 1.30.
Optionally, here you can change the number of blocks each tileset has (first tileset is 0)
If the tileset is in the upperpart it has 200 blocks automatically.

[1]
Blocks=$90

...

[24]
Blocks=$87



********************************
***          Greets          ***
********************************
A huge greeting goes to:
Jigglypuff for the Source of Goldmap2 Beta
and Jay, who gave it to me.

Further greets go to:
Tauwasser and F-Zero for their tutorials.
Mikaron for his work.
Serwe for giving me a few ideas.
And of course, Filb for his board.
