********************************
***   Advance Map Ver 1.49   ***
********************************

Ce programme peut �tre utilis� pour modifier les cartes, informations sur le mouvement possible,
Events et les infos sur les Pok�mon sauvages qui apparaissent.
Dans le future les infos 'collision' c-�-d s'il y  collision avec un object, ou si
on marche tout simplement dessus... peuvent aussi �tre modifi�es.
Il fonctionne avec Pok�mon Rubin et Saphire, Japonais, Anglais et Allemand (Saphire).

!!!Attention!!!
-------------
Dans cette version, toutes modifications sont sauvegard�es directement dans le ROM.
En cliquant sur 'Sauvegarder sous', on peut sauvegarder le carte actuelle dans un autre fichier.
Le fichier est tout d'abord cr�e, en copiant le fichier actuelle.
Tous les autres modifications sont alors sauvegard�es dans le nouvel fichier.


.:|IMPORTANT|:.
-^-^-^-^-^-^-^-
Ce programme a �t� �crit par LU-HO Pok�, et est ainsi Copyright by LU-HO Pok�!
Si vous l'avez t�l�charg� d'un autre site que de (Filb's World Board[ http://www.filbboard.de ]),
dites le moi, s-v-p! Mon adresse e-mail: lu.ho@tiscali.ch



*****************************
***   Very important!!!   ***
*****************************
As some people still want me to make public my sourcecode, I talked one more time to Jiggly.
We came to the conclusion, that GoldMap ist Copyright by Jiggly (for sure anyway) and that
AdvanceMap, with all its versions (older, current, and future one) is Copyright by LU-HO!
So, Advance Map is my product, and I keep all right for it!



*********************************
***     Contenu des inis      ***
*********************************
AdvanceMap.ini:
--------------- 
Ici on trouve le nom du ROM, et quelques propri�t�s comme p.ex.:
MapBankHeader: Offset du MapBank Header
NamenHeader= Offset du Header des noms(cartes)
WildePokemon= Offset du Header des Pok�mon sauvages
TilesetHeader= Offset du Header des 'Tilesets'

Il faut absolument mettre un "$" en face d'une valeur en HEX!


Main.ini
--------
Ici on trouve les dossiers avec les diff�rentes cartes.
On peut cr�er un nombre infini de nouveaux dossiers
La structure est la suivante:
[0]
1=0.0
2=0.1
3=0.2
...

[1]
1=1.0
...

Les noms des dossiers peuvent �tre chang�s librement;


Maps.ini
--------
Ici on trouve les cartes; on y trouve que ceux qui sont
nomm�es dans la liste des dossiers.

[0.0]
Name=PETALBURG CITY
Offset=$287904

[1.0]
Name=Route 101
Offset=$29C8F4

Important:
Ici, c'est mieux de modifier seulement la 'Name' (nom)-propri�t�.
"[0.0]" se rallie sur la position dans le MapHeader.
Si on modifie ceci, la carte ne fonctionne plus!
Les 'offsets' ne sont plus utilis�s, mais ils peuvent quand m�me rester dedans.


Tilesets.ini
------------
Les images 'Tileset' sont charg�es directement du jeu � partir de la version 1.30.
De plus on y peut voir pour chaque 'tileset' (premier Tileset est 0) combien de blocs il occupe. "Blocks=$90".
Si un Tileset se trouve dans la partie sup�rieure, il a automatiquement 200 blocs.

[1]
Blocks=$90

...

[24]
Blocks=$87


Pokemon.ini
-----------
L�, on trouve les noms des Pok�mons:
[Pokemon]
0=Bitte w�hlen     // ceci doit rester, sinon, les infos peuvent �ventuellement �tre mal charg�es.
1=Bisasam
2=Bisaknosp
3=Bisaflor
... 


Sprachen.ini
------------
On y trouve les donn�es pour les diff�rentes langues.
On peut introduire une infinit� d'autres langues, mais veuillez lire le 'contract'.
La langue peut �tre chang�e sous '"Configuration" --> "Langue"'.

La langue toute en haut, est utilis�e comme langue standart. Si il n'y a pas de donn�es,
le programme utilise les descriptions standarts, allemandes.


GehDaten.ini
------------
Ici on trouve les significations des Infos � propos du mouvement. Elles sont aussi disponibles dans
plusieures langues.
Attention: Les inscriptions ([Deutsch]/[English]/...) doivent porter le m�me nom que dans la "Sprachen.ini"!
Les donn�es doivent �tre introduites par des valeures HEX de 2 chiffres/lettres:
[Deutsch]
00=Durchl�ssigkeit immer
...
0C=Mit allen Dingen Begehbar
...



********************************
***          Greats          ***
********************************
Le plus grand salut va � Jigglypuff:
pour le CodeSource de Goldmap2 Beta
et � Jay, qui l'a transmis.

D'autres saluts vont �:
Tauwasser et F-Zero pour leurs tutoriels.
Mikaron pour ses services.
Serwe qui m'a men� � quelques id�es.
Mulle qui m'a dit une erreur dans le programme.
darkmaster01, Chiklit et Mikaron pour leurs traductions.
Et naturellement Filb pour son Board.