********************************
***   Advance Map Ver 1.60   ***
********************************

Dieses Programm ist f�r das Editieren von Maps, Gehdaten, Blockdaten, Events und Wildepokemondaten.
So eine art Kollisionsdaten sind auch editierbar. Sie sind auch im Block-Editor enthalten.
AM l�uft mit:
- Pokemon Ruby und Sappiere alle Sprachen.
- Pokemon Feuer Rot und Blatt Gr�n alle Sprachen.
- Pokemon Emerald in Japanisch.
Um f�r Emerald weitere Sprachen hinzuzuf�gen muss AdvanceMap.ini angepasst werden.

Bei den Feuer Rot und Blatt Gr�n Versionen k�nnen die Wildepokemondaten nicht ge�ndert werden.
Ebenfalls Kann der Name der beim Betreten der Map angezeigt wird nicht ge�ndert werden.

!!!Achtung!!!
-------------
Bei dieser Version werden alle �nderungen direkt ins Rom gespeichert!
Durch Speichern unter kann man die aktuelle Map in eine andere Datei speichern.
Die Datei wird zuerst erstellt, indem die aktuelle Datei kopiert wird.
Alle weiteren �nderungen werden dann in die neue Datei gespeichert.



.:|WICHTIG|:.
-^-^-^-^-^-^-
Dieses Programm wurde von LU-HO Pok� programmiert und ist somit Copyright by LU-HO Pok�!
Dies wurde von Jiggly (programmierer von Goldmap 2 Beta) Officiel best�tigt.
Wen ihr AM von wo anderst als direkt bei http://am160.no-ip.info, vom FWB(Filb's World Board), von www.LU-HO.ch.vu, von
www.romhackersworld.de.vu oder von www.pokeblitz.de runtergeladen habt, richtet mir das Bitte per E-Mail aus!



****************************
***   Ganz Wichtig!!!!   ***
****************************
Ich habe mich mit Jiggly(programmierer von Goldmap 2 Beta) unterhalten, da ein paar Leute
immer noch darauf bestehen das ich den Source frei gebe.
Wir sind auf das Ergebnis gekommen, das Goldmap Copyright By Jiggly ist (ist ja klar) und
das Advance Map, also alle Versionen (alte, jetzige und zuk�nftige) Copyright By LU-HO sind!
Advance Map ist somit mein Produkt und ich besitze alle Recht daf�r!



********************************
***     Inhalt der inis      ***
********************************
AdvanceMap.ini:
--------------- 
Hier steht der Name des Roms und einige Eigenschaften z.B.:
MapBankHeader= Offset des MapBank Headers
NamenHeader= Offset des NamenHeaders(Maps)
WildePokemon= Offset des Wilden Pokemon Headers
TilesetHeader= Offset des Tileset Headers

Bei Hex Werten muss ein "$" davor stehen!


Main.ini
--------
Hier sind die Ordner mit den entsprechenden Maps aufgelistet.
Es k�nnen beliebig Viele neue Ordner erstelt werden.
Der Aufbau sieht so aus:
[0]
1=0.0
2=0.1
3=0.2
...

[1]
1=1.0
...

Die Ordnernamen d�rfen frei ge�ndert werden;


Maps.ini
--------
Hier sind die Maps aufgelistet, es erscheinen nur die,
welche in der liste der Ordner vorkommen.
[0.0]
Name=PETALBURG CITY
Offset=$287904

[1.0]
Name=Route 101
Offset=$29C8F4

Wichtig:
Hier sollte man nur die 'Name'- Eigenschaft �ndern.
Die Namensgebung des Eintrages "[0.0]" bezieht sich auf die Position im Mapheader,
wird dies ge�ndert, funktionieren diese Maps nicht mehr!
Die offsets werden nicht mehr gebarauch, d�rfen aber trozdem drin bleiben.


Tilesets.ini
------------
Die Tileset-Bilder werden ab der ver 1.30 aus dem spiel geladen.
Optional kann hier zu jedem Tileset(erstes Tileset ist 0) stehen wie viele Blocks es hat "Blocks=$90".
Wenn sich ein Tileset im oberen Teil befindet, hat es automatisch 200 Bl�cke.

[1]
Blocks=$90

...

[24]
Blocks=$87


Sprachen.ini
------------
Da sind die Daten f�r die verschiedenen Sprachen auf gelistet.
Es k�nnen beliebig viele andere Sprachen hinzugef�gt werden, beachten sie aber den "EndNutzer Vertrag".
Die Sprache ist unter "Einstellungen"->"Sprache" ausw�hlbar.

Die Sprache, die hier zu oberst steht, wird als Standart Sprache genommen, sind keine Daten vorhanden,
wird die Standart Deutsche Beschriftung verwendet.


GehDaten.ini
------------
Hier stehen die bedeutungen der GehDaten. Sie sind auch in verschiedenen Sprachen vorhanden.
Achtung:Die Eintr�ge ([Deutsch]/[English]/...) m�ssen die gleichen namen haben wie bei der "Sprachen.ini"!
Die werte m�ssen mit 2 stellingen Hexzahlen angegeben werden:
[Deutsch]
00=Durchl�ssigkeit immer
...
0C=Mit allen Dingen Begehbar
...


AufgabenDaten.ini
-----------------
Darin werden die Informationen f�r die "koolisationsdaten" gespeichert.
Hier ist das system etwas anderst. Es gibt wieder Eintr�ge mit den gleichen naen wie in Sprachen.ini,
darin git es aber nur 2 Parameter "Aufgaben" und "Hintergrund" welche bestimmen,
unter welchen Titeln die Daten selbst abgelegt sind.

[Deutsch]
Aufgaben=Aufgaben
Hintergrund=Hintergrund

[English]
Aufgaben=Tasks
Hintergrund=Background

[Aufgaben]
02=Animation von Gras(Pokemon) 
03=Animation hoches Grass 
...

[Hintergrund]
10=Block wird von HIRO verdeckt
...

[Tasks]
...


********************************
***          Greats          ***
********************************
Der gr�sste Gruss geht an:
Jigglypuff f�r den Source von Goldmap2 Beta
und Jay, der ihn �bermittelt hat.

Weitere gr�sse gehen an:
Tauwasser und F-Zero f�r Ihre Tuts.
Mikaron f�r seine Dienste.
Serwe der mich auf ein paar Ideen gebracht hat.
Mulle die mich auf einen Feher hinwies.
Darkmaster01, Chiklit und Mikaron f�r die �bersetzungen.
Und nat�rlich Filb f�r sein Board.
Ein Weiterer Dank geht an F-Zero der mir bei den Paletten f�r die Sprites sehr geholfen hat.
Auch an Darkmaster01 geht f�r seine hilfe Bei den Sprites einen grossen Dank.