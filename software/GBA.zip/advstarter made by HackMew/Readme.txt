                                         �������
          /���������������������������ܲ������۲����۲���������������������������\
 +------------------------------------------------------------------------------------------+
 |     @@8      @@@@@@@@@@    @@      ;@@      @@@       @@i      @@  @@@@@@@@@@  @@@@@@@@@ |
 |   X@@7@@     @@       @@    @@     @@      @@ @@      @@@@@    @@  @@      @@  @@        |
 |  X@@  @@@    @@       @@     @@  @@a      @@2  @@     @8 Z@@@  @@  @@          @@@@@@@   |
 | a@@    @@@   @@       @@      @@@@r      @@     @@    @@   X@@@@@  @@      @@  @@        |
 |@@@@@@Z  @@@  @@@@@@@@@@        @@r      @@@@@@   @@   @@     r@@@  @@@@@@@@@@  @@@@@@@@@ |                                                                              
 |                                                                                          |
 |   .@@@@@@@@@  @@@@@@@@@@@     @@@       @@@@@@@@@.  @@@@@@@@@@@  @@@@@@@@@  @@@@@@@@@.   |  
 |   @@              @@@        @@@@@      @@      @@      @@@      @@         @@      @@   |  
 |   @@@@@@@@@@      @@@       @@@  @@     @@@@@@@@@       @@@      @@@@@@     @@@@@@@@@    |  
 |           @@      @@@      @@a    @@    @@   @@         @@@      @@         @@   @@      |  
 |   @@@@@@@@@.      @@@     @@@@@@   @@   @@     @@       @@@      @@@@@@@@@  @@     @@    |
 +------------------------------------------------------------------------------------------+   
          \���������������������������ܲ������۲����۲���������������������������/
                                          �������

			Advance Starter (aka A-Starter) v1.2.75

		    Copyrigth 2006 Andrea Sartori aka Mew2 aka HackMew


 ===========================================================================================
					-DESCRIPTION-
 ===========================================================================================

		A program to change Starter Pok�mon in a Pok�mon-Advance ROM.

 ===========================================================================================
				       -ROM SUPPORTED-
 ===========================================================================================
		
		+ Ruby (Japanese, English, Italian, Spanish, French, German)
		+ Sapphire (Japanese, English, Italian, Spanish, French, German)
		+ Emerald (Japanese, English, Italian, Spanish, French, German)
		+ Fire Red (Japanese, English, Italian, Spanish, French, German)
		+ Leaf Green (Japanese, English, Italian, Spanish, French, German)

 ===========================================================================================
					 -REVISION-
 ===========================================================================================

 v1.2.00 - First release.
 v1.2.07 - Started to optimizing the GUI and to shrinking the code.
 v1.2.12 - Added a proper ROM check. Now you can load only supported ROM.
 v1.2.15 - Added .ini check.
 v1.2.30 - Update about screen.
 v1.2.40 - Shrinked a bit the code. Now the program should be faster.
 v1.2.55 - Improved the so called "Supported ROM Check". Little change to the code.
 v1.2.60 - Added String Table in the resource file.
 v1.2.65 - Added online update feauture.
 v1.2.69 - Optimized update feature.
 v1.2.75 - General revision of all program code.
 v1.2.79 - Another optimization of the code.

 ===========================================================================================
				       -INSTRUCTIONS-
 ===========================================================================================

 1) Open your favourite ROM.
 2) Now you can see the the list for your and rival's Pok�mon.
 3) Choose what Pok�mon you want from the lists and save when you're done.
 4) There isn't a fouth step! You have already finished! XD

 NOTE [only for RSE ROM!] - you may switch from Male to Female option and viceversa
			    to change May and Brendan's Pokemon.
 					
 Enjoy ;)